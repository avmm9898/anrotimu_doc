using System;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;

namespace Uranus.Utilities
{
    static class iniFile
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
            
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
            
        private static string Path;

        static iniFile() 
        {
            Path = Directory.GetCurrentDirectory();
        }

        //section=配置組，key=鍵名，value=鍵值
        public static void Write(string section, string key, string value)
        {
            string FileName = Path + "\\params.ini";
            if (!File.Exists(FileName))
            {
             //   File.Create(FileName);
            }
            // section=配置節，key=鍵名，value=鍵值，path=路徑
             WritePrivateProfileString(section, key, value, FileName);
        }
        public static string Read(string section, string key)
        {
            string FileName = Path + "\\params.ini";
            if (!File.Exists(FileName))
            {
                return null;
            }
            // 每次從ini中讀取多少字節
            System.Text.StringBuilder temp = new System.Text.StringBuilder(1024);

            // section=配置節，key=鍵名，"":無法讀取時候的缺省數值 temp=上面，path=路徑
            GetPrivateProfileString(section, key, "", temp, 1024, FileName);
            return temp.ToString();
        }
        //檢測是否存在ini 文件
        public static  bool ExistINIFile()
        {
            string FileName = Path + "\\params.ini";
            return File.Exists(FileName);
        } 

    }
}

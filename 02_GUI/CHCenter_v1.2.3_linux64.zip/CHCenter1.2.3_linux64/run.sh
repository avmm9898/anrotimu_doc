sudo env LD_LIBRARY_PATH=lib ./app
